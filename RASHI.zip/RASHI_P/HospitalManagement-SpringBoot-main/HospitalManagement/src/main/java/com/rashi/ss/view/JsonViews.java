package com.rashi.ss.view;

public class JsonViews {

	public interface CommonJsonView{
		
	}
	
	public interface AppointmentJsonView extends CommonJsonView{
		
	}
	
	public interface DoctorJsonView extends CommonJsonView{
		
	}
	
	public interface PatientJsonView extends CommonJsonView{
		
	}
	
	public interface InsuranceJsonView extends CommonJsonView{
		
	}
}
