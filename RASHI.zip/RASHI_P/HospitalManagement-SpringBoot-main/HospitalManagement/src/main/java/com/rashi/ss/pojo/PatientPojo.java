package com.rashi.ss.pojo;

import com.rashi.ss.util.Enums.InsuranceTypes;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PatientPojo {

	private String patientName;
	private String insuranceProvider;
	private InsuranceTypes insuranceType;
	private double insuranceSum;
}
