/*package com.rashi.ss.pojo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginInfoPojo {

	private String username;
	private String password;
}
*/