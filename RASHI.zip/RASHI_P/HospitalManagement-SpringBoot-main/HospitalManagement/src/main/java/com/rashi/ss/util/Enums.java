package com.rashi.ss.util;

public class Enums {

	public enum DoctorQualifications{
		MBBS,MD,BMBS
	}
	
	public enum DoctorDepartments{
		Anaesthesiology, Cardiology, Gynecology, Neurosurgery, Pediatrics
	}
	
	public enum InsuranceTypes{
		Life, Health, Term
	}
}
