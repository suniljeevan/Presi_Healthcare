package com.billing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BillingManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(BillingManagementApplication.class, args);
	}

}
