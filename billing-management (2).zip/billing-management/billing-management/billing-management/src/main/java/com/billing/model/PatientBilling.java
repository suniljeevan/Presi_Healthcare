package com.billing.model;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "patient_billing")
public class PatientBilling {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer billId;
    private String name;
    private String contact;
    private Double appointmentFee;
    private Double medicalExpenses;
    private Double totalExpenses = 0.0;
	public Double getTotalExpenses() {
		// TODO Auto-generated method stub
		return totalExpenses;
	}
	public Double getMedicalExpenses() {
		// TODO Auto-generated method stub
		return medicalExpenses;
	}
	public Double getAppointmentFee() {
		// TODO Auto-generated method stub
		return appointmentFee;
	}
	public void setTotalExpenses(double d) {
		// TODO Auto-generated method stub
		
	}
	public Integer getBillId() {
		return billId;
	}
	public void setBillId(Integer billId) {
		this.billId = billId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getContact() {
		return contact;
	}
	public void setContact(String contact) {
		this.contact = contact;
	}
}
